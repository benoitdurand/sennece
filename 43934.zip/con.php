<?php
$bdd = new PDO('mysql:host=localhost;dbname=export', 'root', 'root');
$bdd->exec('SET NAMES utf8');
?>
