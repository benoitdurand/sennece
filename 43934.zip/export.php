<?php

require('con.php');

$req = $bdd->prepare('SELECT * FROM ventes');
$req->execute();
$ventes = $req->fetchAll();

if(!empty($_POST['format'])){
  $format = strip_tags($_POST['format']);

  switch($format){
    case 'csv':

    header("Content-type: application/csv");
    header('Content-Disposition: attachment; filename='.uniqid().'.csv');

    $handle = fopen('php://output', 'w');
    fputcsv($handle, [
        'Article',
        'Prix',
        'Quantité',
        'Chiffre affaire'
      ]);

    foreach($ventes as $v){
      fputcsv($handle, [
          $v['article'],
          $v['prix'],
          $v['qty'],
          number_format($v['qty'] * $v['prix'], 2, '.',' ')
        ]);
    }

    fclose($handle);exit;

    break;

    case 'xml':

    $xml = new SimpleXMLElement('<xml/>');
    $track = $xml->addChild('export');
    foreach($ventes as $v){
      $track->addChild('article',$v['article']);
      $track->addChild('prix',$v['prix']);
      $track->addChild('qty',$v['qty']);
      $track->addChild('ca', number_format($v['prix'] * $v['qty'], 2, '.', ' '));
    }

    header('Content-type: text/xml');
    header('Content-Disposition: attachment; filename='.uniqid().'.xml');

    print $xml->asXML();

    break;

    default:
    echo 'Faut choisir un format';
    break;
  }
}

?>
